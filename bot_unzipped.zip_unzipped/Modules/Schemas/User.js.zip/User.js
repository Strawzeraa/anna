const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  coins: {
    type: Number,
    default: 0
  },
  lastDaily: {
    type: Number,
    default: null
  },
  lastWork: {
    type: Number,
    default: null
  },
  lastInvest: {
    type: Number,
    default: null
  },
  lastFish: {
    type: Number,
    default: null
  },
  lastCasino: {
    type: Number,
    default: null
  },
  lastRaffle: {
    type: Number,
    default: null
  },
  raffleEntries: {
    type: Number,
    default: 0
  },
  raffleEntriesDiaria: {
    type: Number,
    default: 0
  },
  raffleEntriesSuper: {
    type: Number,
    default: 0
  },
  raffleEntriesMega: {
    type: Number,
    default: 0
  },
  lastRaffleDiaria: {
    type: Number,
    default: null
  },
  lastRaffleSuper: {
    type: Number,
    default: null
  },
  lastRaffleMega: {
    type: Number,
    default: null
  },
  // Adicionando o campo para controlar o cooldown do crime
  lastCrimeTime: {
    type: Number,
    default: null
  },
  lastRaceTime: {
    type: Number, // Adicionando a data do último tempo de aposta na corrida
    default: null
  }
});

module.exports = mongoose.model('User', UserSchema);