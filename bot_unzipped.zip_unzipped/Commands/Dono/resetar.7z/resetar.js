const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const Rifa = require("../../Modules/Schemas/Rifa");

module.exports = {
  name: "resetar",
  description: "Reseta todas as rifas, removendo participantes e tickets.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    try {
      // Reseta todas as rifas no banco de dados
      const rifas = await Rifa.find({});

      if (rifas.length === 0) {
        return interaction.reply({ content: "Não há rifas para resetar.", ephemeral: true });
      }

      for (const rifa of rifas) {
        // Limpa participantes e zera os tickets comprados
        rifa.participants = [];
        rifa.ticketsBought = 0;
        rifa.lastWinner = { userId: "N/A", username: "Ninguém", tag: "Desconhecido", prize: "N/A" };

        // Salva as alterações
        await rifa.save();
      }

      const embed = new EmbedBuilder()
        .setTitle("🔄 Rifas Resetadas!")
        .setDescription("Todas as rifas foram resetadas com sucesso! Todos os participantes e tickets foram removidos.")
        .setColor("Green");

      return interaction.reply({ embeds: [embed], ephemeral: true });

    } catch (err) {
      console.error("Erro ao resetar as rifas:", err);
      return interaction.reply({ content: "Houve um erro ao tentar resetar as rifas. Tente novamente!", ephemeral: true });
    }
  }
};