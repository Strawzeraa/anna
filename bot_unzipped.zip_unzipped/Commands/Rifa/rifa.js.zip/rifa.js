const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const Rifa = require("../../Modules/Schemas/Rifa");
const User = require("../../Modules/Schemas/User");

module.exports = {
  name: "rifa",
  description: "Compre tickets para rifas ou veja o status das rifas.",
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "comprar",
      description: "Compre tickets para uma rifa.",
      type: ApplicationCommandOptionType.Subcommand,
      options: [
        {
          name: "tipo",
          description: "Tipo de rifa (diaria, super, mega).",
          type: ApplicationCommandOptionType.String,
          required: true,
          choices: [
            { name: "Diária", value: "diaria" },
            { name: "Super", value: "super" },
            { name: "Mega", value: "mega" }
          ]
        },
        {
          name: "quantidade",
          description: "Número de tickets que deseja comprar.",
          type: ApplicationCommandOptionType.Integer,
          required: true
        }
      ]
    },
    {
      name: "status",
      description: "Veja o status de uma rifa.",
      type: ApplicationCommandOptionType.Subcommand,
      options: [
        {
          name: "tipo",
          description: "Tipo de rifa para ver o status.",
          type: ApplicationCommandOptionType.String,
          required: true,
          choices: [
            { name: "Diária", value: "diaria" },
            { name: "Super", value: "super" },
            { name: "Mega", value: "mega" }
          ]
        }
      ]
    }
  ],

  run: async (client, interaction) => {
    const sub = interaction.options.getSubcommand();
    const tipo = interaction.options.getString("tipo");
    const quantidade = interaction.options.getInteger("quantidade") || 0;
    const userId = interaction.user.id;

    // Utilize cache para otimizar
    let user = await User.findOne({ userId }) || await User.create({ userId });
    
    // Verificar status da rifa
    if (sub === "status") {
      const rifa = await Rifa.findOne({ type: tipo });
      
      if (!rifa) {
        return interaction.reply({ content: `Ainda não há rifas do tipo **${tipo}** disponíveis.`, ephemeral: true });
      }

      const ticketInfo = rifa.participants.find(p => p.userId === userId);
      const ticketsUser = ticketInfo?.tickets || 0;

      const embed = new EmbedBuilder()
        .setTitle(`${tipo.charAt(0).toUpperCase() + tipo.slice(1)} Rifa - Status`)
        .setDescription(`
🎁 **Prêmio:** ${rifa.prize}
💸 **Preço por ticket:** ${rifa.ticketPrice} rubis
🎟️ **Tickets vendidos:** ${rifa.ticketsBought}
👥 **Participantes:** ${rifa.participants.length}
🧾 **Seus tickets:** ${ticketsUser}
⏳ **Sorteio em:** <t:${Math.floor(rifa.drawTime / 1000)}:R>
🏆 **Último ganhador:** ${rifa.lastWinner?.username || "Ninguém"} (${rifa.lastWinner?.prize || "N/A"})
        `)
        .setColor("Random");

      return interaction.reply({ embeds: [embed] });
    }

    // Comprar tickets
    if (sub === "comprar") {
      if (quantidade <= 0) {
        return interaction.reply({ content: "Você precisa comprar pelo menos 1 ticket.", ephemeral: true });
      }

      let rifa = await Rifa.findOne({ type: tipo });

      // Cria uma rifa nova se não existir
      if (!rifa) {
        const prices = { diaria: 500, super: 10000, mega: 20000 };
        const premios = { diaria: "10.000 rubis", super: "100.000 rubis", mega: "200.000 rubis" };

        rifa = await Rifa.create({
          type: tipo,
          prize: premios[tipo],
          ticketPrice: prices[tipo],
          drawTime: Date.now() + 86400000, // 24h
          participants: [],
          ticketsBought: 0,
          lastWinner: { userId: "N/A", username: "Ninguém", tag: "Desconhecido", prize: "N/A" }
        });
      }

      const total = rifa.ticketPrice * quantidade;

      if (user.coins < total) {
        return interaction.reply({ content: `Você precisa de ${total} rubis para comprar ${quantidade} ticket(s).`, ephemeral: true });
      }

      // Atualizar usuário e rifa de maneira otimizada
      user.coins -= total;

      // Atualiza as entradas de rifa do usuário
      const entryField = `raffleEntries${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
      user[entryField] += quantidade;
      user[`lastRaffle${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`] = Date.now();

      // Atualiza ou cria um participante na rifa
      const participante = rifa.participants.find(p => p.userId === userId);
      if (participante) {
        participante.tickets += quantidade;
      } else {
        rifa.participants.push({ userId, tickets: quantidade });
      }

      rifa.ticketsBought += quantidade;

      // Salva todos os dados ao mesmo tempo
      await Promise.all([user.save(), rifa.save()]);

      return interaction.reply({ content: `🎟️ Você comprou ${quantidade} ticket(s) para a Rifa ${tipo}. Boa sorte!` });
    }
  }
};