const Discord = require('discord.js');
const User = require('../../Modules/Schemas/User');

module.exports = {
  name: 'perfil',
  description: 'Veja seu perfil completo (rubis, casamento etc)',
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'usuário',
      description: 'A pessoa que você quer ver o perfil',
      type: Discord.ApplicationCommandOptionType.User,
      required: false
    }
  ],

  run: async (client, interaction) => {
    const alvo = interaction.options.getUser('usuário') || interaction.user;
    const userData = await User.findOne({ userId: alvo.id });

    if (!userData) {
      return interaction.reply({
        content: 'Essa pessoa ainda não tem perfil no sistema. Peça para usar algum comando antes!',
        ephemeral: true
      });
    }

    let casadoCom = 'Solteiro(a) ❤️‍🔥';
    let totalFilhos = userData.filhos?.length || 0;

    if (userData.marriedTo) {
      casadoCom = `<@${userData.marriedTo}> 💍`;
      const parceiroData = await User.findOne({ userId: userData.marriedTo });
      if (parceiroData) {
        // Filhos em comum (evita duplicar filhos com mesmo nome + nascimento)
        const filhosUnicos = new Map();
        for (const filho of [...userData.filhos, ...parceiroData.filhos]) {
          const key = `${filho.nome}-${filho.nascimento}`;
          filhosUnicos.set(key, filho);
        }
        totalFilhos = filhosUnicos.size;
      }
    }

    const embed = new Discord.EmbedBuilder()
      .setColor('#ff69b4')
      .setTitle(`✨ Perfil de ${alvo.username}`)
      .setThumbnail(alvo.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `**Rubis:** \`${userData.coins} 💎\`\n` +
        `**Status:** ${casadoCom}\n` +
        `**Filhos:** \`${totalFilhos} 👶\``
      )
      .setFooter({ text: 'Use /casar para mudar esse status amoroso!' });

    interaction.reply({ embeds: [embed] });
  }
};