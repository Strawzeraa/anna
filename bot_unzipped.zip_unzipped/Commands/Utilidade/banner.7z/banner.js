const Discord = require("discord.js");

const lojaDeBanners = {
  '01': {
    nome: 'Uma paisagem qualquer',
    url: 'https://imgur.com/qw7jh7V.jpeg',
    preco: 2000
  },
  '02': {
    nome: 'Gnominha',
    url: 'https://i.imgur.com/KFePxns.png',
    preco: 10500
  },
  '03': {
    nome: 'Noite',
    url: 'https://i.imgur.com/znaysLg.png',
    preco: 15000
  }
};

module.exports = {
  name: 'banner',
  description: 'Veja todos os banners disponíveis na loja!',
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const embed = new Discord.EmbedBuilder()
      .setColor('Blue')
      .setTitle('Banners disponíveis')
      .setDescription('Confira os banners que você pode comprar na loja:')
      .addFields(
        Object.entries(lojaDeBanners).map(([id, banner]) => ({
          name: `ID: ${id} - ${banner.nome}`,
          value: `Preço: ${banner.preco} rubis\n[Visualizar Banner](${banner.url})`
        }))
      );

    return interaction.reply({ embeds: [embed] });
  }
};