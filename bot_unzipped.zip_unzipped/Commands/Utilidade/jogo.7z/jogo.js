const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');

module.exports = {
  name: 'jogodavelha',
  description: 'Jogue jogo da velha contra a Anna!',
  type: 1,

  run: async (client, interaction) => {
    const empty = '⬜';
    const playerSymbol = '❌';
    const botSymbol = '⭕';
    let board = Array(9).fill(empty);

    const checkWin = (symbol) => {
      const winConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
      ];
      return winConditions.some(combo =>
        combo.every(index => board[index] === symbol)
      );
    };

    const getButtons = () => {
      const rows = [];
      for (let i = 0; i < 3; i++) {
        const row = new ActionRowBuilder();
        for (let j = 0; j < 3; j++) {
          const index = i * 3 + j;
          row.addComponents(
            new ButtonBuilder()
              .setCustomId(index.toString())
              .setLabel(board[index])
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(board[index] !== empty)
          );
        }
        rows.push(row);
      }
      return rows;
    };

    const embed = new EmbedBuilder()
      .setTitle('🎮 Jogo da Velha - Você vs Anna')
      .setDescription('Jogue contra mim! Clique em um dos quadrados abaixo.')
      .setColor('#f9a8d4');

    await interaction.reply({
      embeds: [embed],
      components: getButtons()
    });

    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({
      filter: i => i.user.id === interaction.user.id,
      time: 60000
    });

    collector.on('collect', async i => {
      const index = parseInt(i.customId);

      if (board[index] !== empty) return;

      board[index] = playerSymbol;

      if (checkWin(playerSymbol)) {
        collector.stop('player_win');
        return i.update({
          embeds: [embed.setDescription('Você venceu! Parabéns!')],
          components: getButtons()
        });
      }

      if (!board.includes(empty)) {
        collector.stop('draw');
        return i.update({
          embeds: [embed.setDescription('Empate!')],
          components: getButtons()
        });
      }

      // Jogada do bot
      let botMove;
      const available = board.map((val, idx) => val === empty ? idx : null).filter(val => val !== null);
      botMove = available[Math.floor(Math.random() * available.length)];
      board[botMove] = botSymbol;

      if (checkWin(botSymbol)) {
        collector.stop('bot_win');
        return i.update({
          embeds: [embed.setDescription('Eu venci! Boa tentativa!')],
          components: getButtons()
        });
      }

      if (!board.includes(empty)) {
        collector.stop('draw');
        return i.update({
          embeds: [embed.setDescription('Empate!')],
          components: getButtons()
        });
      }

      await i.update({
        components: getButtons()
      });
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') {
        message.edit({
          embeds: [embed.setDescription('Tempo esgotado!')],
          components: getButtons().map(row => {
            row.components.forEach(btn => btn.setDisabled(true));
            return row;
          })
        });
      }
    });
  }
};