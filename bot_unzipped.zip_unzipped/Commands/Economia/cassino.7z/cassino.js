const Discord = require('discord.js');
const User = require('../../Modules/Database/User');
const ms = require('ms');

module.exports = {
  name: 'cassino',
  description: 'Jogue no caça-níquel com seus rubis!',
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'valor',
      description: 'Quantia de rubis (mínimo 1000, máximo 10000)',
      type: Discord.ApplicationCommandOptionType.Integer,
      required: true
    }
  ],

  run: async (client, interaction) => {
    const valor = interaction.options.getInteger('valor');
    const userId = interaction.user.id;
    const database = new User();
    const emojis = ['🍒', '💎', '7️⃣', '⭐', '🍋'];
    const cooldown = 3 * 60 * 60 * 1000; // 3 horas

    try {
      const userData = await database.find(userId);
      if (!userData) return interaction.reply({ content: 'Você ainda não possui uma conta.', ephemeral: true });

      // Verificação de cooldown
      const lastUse = userData.lastCasino || 0;
      if (Date.now() - lastUse < cooldown) {
        const restante = ms(cooldown - (Date.now() - lastUse), { long: true });
        return interaction.reply({
          content: `Você já usou o cassino recentemente. Tente novamente em **${restante}**.`,
          ephemeral: true
        });
      }

      // Verificação de valor
      if (valor < 1000 || valor > 10000)
        return interaction.reply({ content: 'Você só pode apostar entre **1.000** e **10.000** rubis.', ephemeral: true });

      if (userData.coins < valor)
        return interaction.reply({ content: 'Você não tem rubis suficientes.', ephemeral: true });

      await interaction.reply({ content: 'Girando as roletas...' });

      const anim = [
        '🎰 | [🍒][💎][7️⃣]',
        '🎰 | [⭐][🍋][🍒]',
        '🎰 | [💎][7️⃣][💎]',
        '🎰 | [🍋][🍒][7️⃣]'
      ];

      for (let i = 0; i < anim.length; i++) {
        await new Promise(r => setTimeout(r, 500));
        await interaction.editReply({ content: anim[i] });
      }

      const slots = [
        emojis[Math.floor(Math.random() * emojis.length)],
        emojis[Math.floor(Math.random() * emojis.length)],
        emojis[Math.floor(Math.random() * emojis.length)]
      ];

      let ganho = 0;
      let multiplicador = 1; // Inicializa o multiplicador
      if (slots[0] === slots[1] && slots[1] === slots[2]) {
        multiplicador = 2; // Ganho máximo (3 iguais)
        ganho = valor * multiplicador;
      } else if (slots[0] === slots[1] || slots[1] === slots[2] || slots[0] === slots[2]) {
        multiplicador = 1.5; // Ganho médio (2 iguais)
        ganho = Math.floor(valor * multiplicador);
      }

      // Ajuste do saldo e dados do usuário
      userData.coins = userData.coins - valor + ganho;
      userData.lastCasino = Date.now();
      await userData.save();

      const embed = new Discord.EmbedBuilder()
        .setColor(ganho > 0 ? 'Green' : 'Red')
        .setTitle('Cassino Rubi')
        .setDescription(
          `**Resultado final:** [${slots.join('][')}]\n\n` +
          (ganho > 0
            ? `- Você apostou \`${valor}\` e **ganhou \`${ganho}\` rubis!**\n- Multiplicador: \`x${multiplicador.toFixed(2)}\``
            : `- Você apostou \`${valor}\` e **perdeu tudo...**`) +
          `\n- Saldo atual: \`${userData.coins}\``
        );

      await new Promise(r => setTimeout(r, 700));
      return interaction.editReply({ content: '', embeds: [embed] });

    } catch (e) {
      console.error(e);
      return interaction.editReply({ content: 'Ocorreu um erro ao rodar o cassino.' });
    }
  }
};